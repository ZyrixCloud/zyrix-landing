/** @type {import('tailwindcss').Config} */
module.exports={content:["./app/**/*.{js,ts,jsx,tsx}","./components/**/*.{js,ts,jsx,tsx}"],theme:{extend:{colors:{brand:{100:"#dbeafe",600:"#2563eb",700:"#1d4ed8"},bg:"#0b1220"}}},plugins:[]};
